angular.module('grade').config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
            when('/assigngrades',{
                templateUrl:'grade/views/create-grade.client.view.html'
            })
    }
]);
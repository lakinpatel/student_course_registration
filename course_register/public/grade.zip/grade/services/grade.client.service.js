angular.module('grade').factory('Grade', ['$resource', function () {
    
}]);